//*******************************************************************
#include "lib.h"
#include "Module/RTOS.h"
//#include <iostream>

//*******************************************************************

class Button{
	
	private:
		int x;
		int y;
		int xLaenge;
		int yLaenge;
//		std::string colour = "Red";
		char* text;
	
	public:
		Button(int x, int y, int xLaenge, int yLaenge, char* text){
			this -> x = x;
			this -> y = y;
			this -> xLaenge = xLaenge;
			this -> yLaenge = yLaenge;
			this -> text = text;
		}
		
		int getX(){
			return x;
		}
		int getY(){
			return y;
		}
		int getXLaenge(){
			return xLaenge;
		}
		int getYLaenge(){
			return yLaenge;
		}
//		String getColour(){
//			return colour;
//		}
//		void setColour(String colour){
//			this -> colour = colour;
//	}
			
//		String getText(){
//			return text;
//		}
		
//		bool contains(int x, int y){
//			return x > this -> x && x < this -> x + xLaenge
//		}
	
};