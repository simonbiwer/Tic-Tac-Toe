//*******************************************************************
#include "lib.h"
#include "Module/RTOS.h"
#include "Button.h"

//*******************************************************************

class View{
	
	private:
		cDevDisplayGraphic& disp;

	public:
		View(cDevDisplayGraphic& dispRef): disp(dispRef){
		}
		
		void createStartView(Button button){
			#ifdef USE_GRAPHIC_DISPLAY
				disp.setBackColor(cHwDisplayGraphic::Navy);
				disp.clear();
				disp.printf(0,0,0,__DATE__ " " __TIME__);

				//Button 1
//				disp.drawFrame(button.getX(), button.getY(), button.getXLaenge(), button.getYLaenge(), 2, cHwDisplayGraphic::Red);
//				disp.drawText(button.getX() + 10, button.getY() + button.getYLaenge()/2, 20, "1 Spieler");
//				disp.drawText(100, 200, 20, "Hier bin ich");
				disp.refresh();
			#endif
		}
};

//EOF