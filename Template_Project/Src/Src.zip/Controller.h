//*******************************************************************
#include "lib.h"
#include "Module/RTOS.h"

//*******************************************************************

class Controller{
	
	private:
		cDevDisplayGraphic& disp;
		View& view;

	public:
		
		bool gameRunning;
	
		Controller(cDevDisplayGraphic& _disp) : disp(_disp), view(_disp){
//			init();
		}
		
		~Controller(){
			//delete Controller::view;
		}
		
		void init(){
//			View view(disp);
//			Controller::view = &view;
			gameRunning = false;
		}
		
		void setUpField(){
			Button button1(100, 250, 200, 100, "1 Spieler");
			view.createStartView(button1);
		}
		
		void beforeGame(cDevControlPointer::cData event){
			// x, y, L�nge x-Richtung, L�nge y-Richtung
			int frame1 [4] = {100, 250, 200, 100};

			int frame2 [4] = {400, 250, 200, 100};
			disp.drawFrame(frame2[0], frame2[1], frame2[2], frame2[3], 2, cHwDisplayGraphic::Red);
			disp.drawText(420, 200, 20, "2 Spieler");
						
			if (event.posX > frame1[0] & event.posX < frame1[0] + frame1[2] & event.posY > frame1[1] & event.posY < frame1[1] + frame1[3]){
				disp.drawText(frame1[0], frame1[1] + frame1[3] + 20, 20, "Es spielt ein Spieler");
			}
			// if button1.contains(event.posX, event.posY)
			
			if (event.posX > frame2[0] & event.posX < frame2[0] + frame2[2] & event.posY > frame2[1] & event.posY < frame2[1] + frame2[3]){
				disp.drawText(frame1[0], frame1[1] + frame1[3] + 20, 20, "Es spielen zwei Spieler");				
			}
			// if button2.contains(event.posX, event.posY)
			
      disp.refresh();
			// Feld zeichnen
			// GameRunning auf true setzen
		}
};

//EOF