#include "Module/JSON.h"

//*******************************************************************
//cJSONobject::cJSONobject(cJSONcontainer &arr )
//: cJSONcontainer(arr)
//{
//  arr.elements.add(this);
////  arr.element = this;
//
//}

