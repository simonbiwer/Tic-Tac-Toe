//*******************************************************************
/*!
\file   Std.cpp
\author Thomas Breuer (Bonn-Rhein-Sieg University of Applied Sciences)
\date   23.03.2016

This file is released under the MIT License.
*/

//*******************************************************************
extern "C"
{
  void __cxa_pure_virtual( void )
  {
    abort();
  }
}

// EOF
