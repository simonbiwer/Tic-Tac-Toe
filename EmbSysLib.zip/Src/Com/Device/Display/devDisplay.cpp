//*******************************************************************
/*!
\file   devDisplay.cpp
\author Thomas Breuer (Bonn-Rhein-Sieg University of Applied Sciences)
\date   25.04.2016

This file is released under the MIT License.
*/

//*******************************************************************
//
// cDevDisplay
//
//*******************************************************************
//-------------------------------------------------------------------
cDevDisplay::cDevDisplay( void )
{
}

//EOF
